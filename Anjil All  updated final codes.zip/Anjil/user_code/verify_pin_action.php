<?php
session_start(); // start session //

// load required helpers //
require_once '../includes/auth_check.php';
require_once '../includes/db.php';
require_once '../includes/user_model.php';
require_once '../includes/validation.php';
require_once '../includes/audit.php';

// only admin can verify PIN //
requireRole(['Admin']);

$pdo = getDB(); // db connection //
$adminID = $_SESSION['userID']; // acting admin ID //
$message = ""; // feedback message //

// --------------------------------------------------------------
// FETCH LOGGED-IN ADMIN PIN HASH
// --------------------------------------------------------------
$stmt = $pdo->prepare("SELECT AdminPINHash FROM admin WHERE UserID = ?");
$stmt->execute([$adminID]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

// if admin row does not exist, stop //
if (!$admin) {
    die("Admin record not found for logged-in user.");
}

// --------------------------------------------------------------
// WHEN FORM SUBMITTED
// --------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // pin entered by acting admin //
    $pin = trim($_POST['admin_pin'] ?? '');

    // action: create / update / delete //
    $action = $_POST['action'] ?? '';

    // for create //
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $role     = $_POST['role'] ?? '';
    $extra    = $_POST['extra'] ?? [];

    // for update/delete //
    $targetUser = $_POST['target_user'] ?? null;
    $isActive   = $_POST['is_active'] ?? 0;
    $newAdminPin = $_POST['new_admin_pin'] ?? null;

    // --------------------------------------------------------------
    // VALIDATE ADMIN PIN FORMAT
    // --------------------------------------------------------------
    if (!preg_match('/^[0-9]{6}$/', $pin)) {
        $message = "<div class='alert alert-danger'>❌ PIN must be exactly 6 digits.</div>";
    }
    elseif (!password_verify($pin, $admin['AdminPINHash'])) {
        // incorrect pin //
        $message = "<div class='alert alert-danger'>❌ Incorrect Admin PIN.</div>";
        logAction($adminID, "PIN Failed", "Admin", null, "Incorrect PIN at verify_pin_action");
    }
    else {

        // --------------------------------------------------------------
        // PIN VERIFIED → EXECUTE REQUESTED ACTION
        // --------------------------------------------------------------

        if ($action === "create") {

            // IMPORTANT:
            // DO NOT insert into admin table here!
            // createUser() handles admin table insert internally.

            $result = createUser($username, $password, $role, $extra);

            if ($result === "exists") {
                $message = "<div class='alert alert-danger'>⚠ Username already exists!</div>";
            } elseif ($result) {
                $message = "<div class='alert alert-success'>✅ User created successfully!</div>";
            } else {
                $message = "<div class='alert alert-danger'>❌ Failed to create user.</div>";
            }
        }

        elseif ($action === "update") {

            // update main user fields //
            $ok = updateUser($targetUser, $username, $password, $role, $isActive);

            if ($ok) {

                $message = "<div class='alert alert-success'>✅ User updated successfully!</div>";

                // handle admin PIN update AFTER user update //
                if ($role === "Admin" && !empty($newAdminPin)) {

                    if (preg_match('/^[0-9]{6}$/', $newAdminPin)) {

                        $newPinHash = password_hash($newAdminPin, PASSWORD_DEFAULT);

                        $pdo->prepare("
                            UPDATE admin 
                            SET AdminPINHash = ?, FailedPinAttempts = 0,
                                PinLastChanged = NOW(), PinLockUntil = NULL
                            WHERE UserID = ?
                        ")->execute([$newPinHash, $targetUser]);

                        $message .= "<div class='alert alert-info'>🔐 Admin PIN updated successfully.</div>";

                    } else {
                        $message .= "<div class='alert alert-warning'>⚠ Invalid new PIN, not updated.</div>";
                    }
                }

            } else {
                $message = "<div class='alert alert-danger'>❌ Failed to update user.</div>";
            }
        }

        elseif ($action === "delete") {

            $ok = deleteUser($targetUser);

            if ($ok) {
                $message = "<div class='alert alert-success'>🗑 User deleted successfully!</div>";
            } else {
                $message = "<div class='alert alert-danger'>❌ Failed to delete user.</div>";
            }
        }

        // log final action //
        logAction($adminID, "Admin Action: $action", "Admin", $targetUser ?: null, "Executed via verify_pin_action.php");
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin PIN Verification</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body style="background:#243B55; padding:40px; font-family:Poppins,sans-serif;">

<div class="card p-4" style="max-width:450px; margin:auto;">

    <h3 class="text-center mb-3">Enter Admin PIN</h3>

    <?= $message ?>

    <form method="POST">

        <!-- forwarding all posted fields safely -->
        <?php foreach ($_POST as $k => $v): ?>
            <?php 
            if (is_array($v)) {
                foreach ($v as $k2 => $v2) {
                    echo "<input type='hidden' name='{$k}[{$k2}]' value='".htmlspecialchars($v2)."'>";
                }
            } else {
                echo "<input type='hidden' name='".htmlspecialchars($k)."' value='".htmlspecialchars($v)."'>";
            }
            ?>
        <?php endforeach; ?>

        <label>Admin PIN</label>
        <input type="password" maxlength="6" name="admin_pin" class="form-control" placeholder="******" required>

        <button class="btn btn-warning w-100 mt-3">Verify PIN</button>
    </form>

    <a href="manage_user.php" class="btn btn-secondary w-100 mt-3">← Back</a>

</div>

</body>
</html>
