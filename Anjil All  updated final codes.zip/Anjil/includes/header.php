<!DOCTYPE html>
<html>
<head>
    <title>User Management</title>

    <!-- Bootstrap -->
    <link 
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" 
        rel="stylesheet">

    <!-- Custom style -->
    <link rel="stylesheet" href="../assets/style.css">

</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="manage_users.php">User Management</a>
  </div>
</nav>

<div class="container mt-4">
