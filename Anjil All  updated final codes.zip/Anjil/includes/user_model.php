<?php
// load db connection file //
require_once 'db.php';
// load audit logger file //
require_once 'audit.php';

// get shared PDO connection instance //
$pdo = getDB();

/*
   get users without pagination
*/
function getUsers($search = "", $role = "", $sort = "UserID", $order = "ASC") {
    global $pdo;

    // allowed sort columns to prevent SQL injection //
    $allowedSort = ["UserID", "Username", "Role", "CreatedDate", "Email"];
    if (!in_array($sort, $allowedSort)) $sort = "UserID";
    // validate sort direction //
    $order = strtoupper($order) === "DESC" ? "DESC" : "ASC";

    // base query //
    $sql = "SELECT * FROM user WHERE 1 ";
    $params = [];

    // add search filter //
    if ($search !== "") {
        $sql .= " AND Username LIKE ? ";
        $params[] = "%$search%";
    }

    // add role filter //
    if ($role !== "") {
        $sql .= " AND Role = ? ";
        $params[] = $role;
    }

    // add order by //
    $sql .= " ORDER BY $sort $order";

    // run query //
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/*
   count users based on filters
*/
function countAllUsers($search = "", $role = "") {
    $pdo = getDB();

    // base count query //
    $sql = "SELECT COUNT(*) FROM user WHERE 1 ";
    $params = [];

    // add search filter //
    if ($search !== "") {
        $sql .= " AND Username LIKE ? ";
        $params[] = "%$search%";
    }

    // add role filter //
    if ($role !== "") {
        $sql .= " AND Role = ? ";
        $params[] = $role;
    }

    // run query and return count //
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return (int)$stmt->fetchColumn();
}

/*
   get users with pagination
*/
function getUsersPaginated($search, $role, $sort, $order, $page, $perPage) {
    $pdo = getDB();

    // allowed sort columns //
    $allowedSort = ["UserID", "Username", "Email", "Role", "CreatedDate"];
    if (!in_array($sort, $allowedSort)) $sort = "UserID";

    // validate order //
    $order = strtoupper($order) === "DESC" ? "DESC" : "ASC";

    // normalise page and perPage //
    $page    = max(1, (int)$page);
    $perPage = max(1, (int)$perPage);
    $offset  = ($page - 1) * $perPage;

    // WHERE section //
    $where  = " WHERE 1 ";
    $params = [];

    // search condition //
    if ($search !== "") {
        $where .= " AND Username LIKE ? ";
        $params[] = "%$search%";
    }

    // role condition //
    if ($role !== "") {
        $where .= " AND Role = ? ";
        $params[] = $role;
    }

    // count total users for pagination //
    $sqlCount = "SELECT COUNT(*) FROM user $where";
    $stm = $pdo->prepare($sqlCount);
    $stm->execute($params);
    $total = (int)$stm->fetchColumn();

    // main paginated query //
    $sql = "
        SELECT *
        FROM user
        $where
        ORDER BY $sort $order
        LIMIT ? OFFSET ?
    ";

    $stm = $pdo->prepare($sql);

    // bind dynamic filters first //
    $pos = 1;
    foreach ($params as $p) {
        $stm->bindValue($pos++, $p);
    }

    // bind limit and offset as integers //
    $stm->bindValue($pos++, (int)$perPage, PDO::PARAM_INT);
    $stm->bindValue($pos++, (int)$offset, PDO::PARAM_INT);

    // execute and fetch //
    $stm->execute();
    $users = $stm->fetchAll(PDO::FETCH_ASSOC);

    // calculate total pages //
    $totalPages = max(1, ceil($total / $perPage));

    // return full pagination result //
    return [
        "users"      => $users,
        "total"      => $total,
        "page"       => $page,
        "perPage"    => $perPage,
        "totalPages" => $totalPages
    ];
}

/*
   get single user by id
*/
function getUserById($id) {
    global $pdo;
    // prepare query //
    $stmt = $pdo->prepare("SELECT * FROM user WHERE UserID = ?");
    // execute with id //
    $stmt->execute([$id]);
    // fetch single row //
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/*
   create user (admin / staff / student)
   - inserts into user table for all roles
   - inserts into staff or student table when role matches
   - inserts into admin table when role = 'Admin'
*/
function createUser($username, $passwordPlain, $role, $extra = []) {
    $pdo = getDB(); // get db connection //

    try {
        // check if username already exists in user table //
        $check = $pdo->prepare("SELECT COUNT(*) FROM user WHERE Username = ?");
        $check->execute([$username]);
        if ($check->fetchColumn() > 0) {
            // username taken, do not create //
            return "exists";
        }

        // start transaction so all inserts happen together //
        $pdo->beginTransaction();

        // build email from extra or default pattern //
        $email = $extra['email'] ?? ($username . "@school.edu");

        // hash password once and reuse (user + admin) //
        $passwordHash = password_hash($passwordPlain, PASSWORD_DEFAULT);

        // insert common user record into user table //
        $stmt = $pdo->prepare("
            INSERT INTO user (Username, PasswordHash, Role, Email, IsActive)
            VALUES (?, ?, ?, ?, 1)
        ");
        $stmt->execute([
            $username,      // username //
            $passwordHash,  // password hash //
            $role,          // role //
            $email          // email //
        ]);

        // get new user id from auto increment //
        $userId = (int)$pdo->lastInsertId();

        // ---------------------------------------------------
        // create admin extra record when role is Admin
        // ---------------------------------------------------
        if ($role === "Admin") {
            // read plain 6-digit pin from extra array //
            $adminPinPlain = $extra['admin_pin'] ?? null;

            // validate that pin is present //
            if ($adminPinPlain === null || $adminPinPlain === '') {
                // pin missing, throw exception to rollback //
                throw new Exception("Admin PIN is required for Admin role.");
            }

            // hash admin pin for secure storage in admin table //
            $adminPinHash = password_hash($adminPinPlain, PASSWORD_DEFAULT);

            // admin password hash = same as user password hash //
            $adminPasswordHash = $passwordHash;

            // default admin level if not provided //
            $adminLevel = $extra['admin_level'] ?? 'Admin';

            // check if an admin row already exists for this user id //
            $checkAdmin = $pdo->prepare("SELECT COUNT(*) FROM admin WHERE UserID = ?");
            $checkAdmin->execute([$userId]);
            $existsAdmin = (int)$checkAdmin->fetchColumn();

            // only insert admin row if it does not already exist //
            if ($existsAdmin === 0) {
                // prepare insert for admin table //
                $stmtAdmin = $pdo->prepare("
                    INSERT INTO admin
                        (UserID, Username, AdminPINHash, AdminPasswordHash, AdminLevel,
                         Email, LastLogin, CreatedAt, FailedPinAttempts, PinLastChanged, PinLockUntil)
                    VALUES
                        (:uid, :uname, :pinHash, :pwdHash, :level,
                         :email, NULL, NOW(), 0, NULL, NULL)
                ");

                // execute admin insert with bound values //
                $stmtAdmin->execute([
                    ':uid'     => $userId,           // link admin row to user.id //
                    ':uname'   => $username,         // same username //
                    ':pinHash' => $adminPinHash,     // hashed pin //
                    ':pwdHash' => $adminPasswordHash,// hashed password //
                    ':level'   => $adminLevel,       // admin level //
                    ':email'   => $email             // admin email //
                ]);
            }
        }

        // ---------------------------------------------------
        // create staff record when role is Staff
        // ---------------------------------------------------
        if ($role === "Staff") {
            // prepare staff insert statement //
            $stmtStaff = $pdo->prepare("
                INSERT INTO staff (UserID, FirstName, LastName, Email, Department, Salary, HireDate, IsActive)
                VALUES (?, ?, ?, ?, ?, ?, ?, 1)
            ");

            // execute staff insert //
            $stmtStaff->execute([
                $userId,                                   // link staff to user id //
                $extra['first_name'] ?? ucfirst($username), // first name //
                $extra['last_name']  ?? "Staff",          // last name //
                $email,                                   // email //
                $extra['department'] ?? null,            // department //
                $extra['salary']     ?? null,            // salary //
                $extra['hire_date']  ?? date("Y-m-d")    // hire date //
            ]);
        }

        // ---------------------------------------------------
        // create student record when role is Student
        // ---------------------------------------------------
        if ($role === "Student") {
            // prepare student insert statement //
            $stmtStudent = $pdo->prepare("
                INSERT INTO student (UserID, FirstName, LastName, DateOfBirth, Email, Age, GPA, IsActive)
                VALUES (?, ?, ?, ?, ?, ?, ?, 1)
            ");

            // execute student insert //
            $stmtStudent->execute([
                $userId,                                   // link student to user id //
                $extra['first_name'] ?? ucfirst($username), // first name //
                $extra['last_name']  ?? "Student",        // last name //
                $extra['dob']        ?? date("Y-m-d"),     // dob //
                $email,                                    // email //
                $extra['age']       ?? null,              // age //
                $extra['gpa']       ?? null               // gpa //
            ]);
        }

        // commit everything if no error happened //
        $pdo->commit();

        // log user creation in audit table //
        logAction(
            null,                               // no acting user id //
            "Created User",                     // action //
            "User",                             // category //
            $userId,                            // target id //
            "Username: $username Role: $role"   // description //
        );

        // return new user id for further use //
        return $userId;

    } catch (Exception $e) {
        // rollback if transaction still active //
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        // you could log $e->getMessage() here if needed //
        return false;
    } catch (PDOException $e) {
        // rollback db errors too //
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        // you could log $e->getMessage() here as well //
        return false;
    }
}

/*
   update user basic fields
*/
function updateUser($id, $username, $password, $role, $isActive) {
    global $pdo;

    // if new password provided, update password too //
    if ($password !== "") {
        $stmt = $pdo->prepare("
            UPDATE user
            SET Username = ?, PasswordHash = ?, Role = ?, IsActive = ?
            WHERE UserID = ?
        ");
        return $stmt->execute([
            $username,
            password_hash($password, PASSWORD_DEFAULT),
            $role,
            $isActive,
            $id
        ]);
    } else {
        // update without password change //
        $stmt = $pdo->prepare("
            UPDATE user
            SET Username = ?, Role = ?, IsActive = ?
            WHERE UserID = ?
        ");
        return $stmt->execute([
            $username,
            $role,
            $isActive,
            $id
        ]);
    }
}

/*
   delete user
   - removes related admin / staff / student rows first
   - then removes main user row
*/
function deleteUser($id) {
    $pdo = getDB(); // fresh db connection //

    try {
        // start transaction so all deletes happen together //
        $pdo->beginTransaction();

        // always try to delete admin row for this user id //
        $stmtAdmin = $pdo->prepare("DELETE FROM admin WHERE UserID = ?");
        $stmtAdmin->execute([$id]);

        // always try to delete staff row for this user id //
        $stmtStaff = $pdo->prepare("DELETE FROM staff WHERE UserID = ?");
        $stmtStaff->execute([$id]);

        // always try to delete student row for this user id //
        $stmtStudent = $pdo->prepare("DELETE FROM student WHERE UserID = ?");
        $stmtStudent->execute([$id]);

        // finally delete from main user table //
        $stmtUser = $pdo->prepare("DELETE FROM user WHERE UserID = ?");
        $stmtUser->execute([$id]);

        // commit deletes //
        $pdo->commit();

        // return true if user row was deleted //
        return ($stmtUser->rowCount() > 0);

    } catch (PDOException $e) {
        // rollback on any error //
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        // you can log $e->getMessage() here //
        return false;
    }
}
