<?php
// File: staff_dashboard.php
// Dashboard for School Management System - Main staff dashboard with statistics and quick actions

// Enable error reporting for debugging during development
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include required files for authentication, database, and authentication model
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth_model.php';

// Initialize variables for dashboard statistics with default values
$pendingUsersCount = 0;
$totalStaffCount = 0;
$recentActivity = [];

try {
    // Get count of pending user approvals for admin display
    $pendingUsersCount = countPendingUsers();
    
    // Get total staff count from database
    $pdo = getDB();
    $stmt = $pdo->query("SELECT COUNT(*) FROM Staff WHERE IsActive = 1");
    $totalStaffCount = $stmt->fetchColumn();
    
    // Get recent login activity (last 5 logins) for activity feed
    $stmt = $pdo->query("
        SELECT Username, LastLogin 
        FROM User 
        WHERE LastLogin IS NOT NULL 
        ORDER BY LastLogin DESC 
        LIMIT 5
    ");
    $recentActivity = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    // Log database errors but don't break the dashboard
    error_log("Dashboard data error: " . $e->getMessage());
}

// Determine user role for role-based content and permissions
$isAdmin = ($_SESSION['role'] === 'Admin');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard - Future Billionaire Academy</title>
    <!-- Include Bootstrap CSS for responsive layout and components -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Include Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Global body styling with gradient background */
        body {
            font-family: "Poppins", sans-serif;
            background: linear-gradient(135deg, #182848, #4b6cb7);
            color: white;
            min-height: 100vh;
        }
        
        /* Glass morphism effect for cards */
        .glass-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 20px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
            border: 1px solid rgba(255, 255, 255, 0.2);
            height: 100%;
        }
        
        /* Dashboard header styling */
        .dashboard-header {
            padding: 30px 0;
            text-align: center;
        }
        
        /* Welcome text styling with accent color */
        .welcome-text {
            color: #f1c40f;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        /* Statistics card hover animation */
        .stat-card {
            transition: transform 0.3s ease;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        /* Statistics icon styling */
        .stat-icon {
            font-size: 2.5rem;
            margin-bottom: 15px;
            color: #f1c40f;
        }
        
        /* Quick action button styling */
        .quick-action {
            background: rgba(255, 255, 255, 0.15);
            border: none;
            color: white;
            padding: 15px;
            border-radius: 10px;
            transition: all 0.3s ease;
            text-align: center;
            display: block;
            text-decoration: none;
            margin-bottom: 15px;
        }
        
        /* Quick action hover effect */
        .quick-action:hover {
            background: rgba(241, 196, 15, 0.3);
            color: white;
            transform: translateY(-3px);
        }
        
        /* User info header styling */
        .user-info {
            background: rgba(255, 255, 255, 0.1);
            padding: 10px 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 14px;
            text-align: right;
        }
        
        /* Activity list styling for recent activity feed */
        .activity-list {
            list-style-type: none;
            padding: 0;
        }
        
        /* Individual activity item styling */
        .activity-item {
            padding: 10px 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        /* Remove border from last activity item */
        .activity-item:last-child {
            border-bottom: none;
        }
    </style>
</head>
<body>
    <div class="container-fluid py-4">
        <!-- User information and navigation header -->
        <div class="user-info">
            Welcome, <strong><?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?></strong> 
            (<?php echo htmlspecialchars($_SESSION['role'] ?? 'Staff'); ?>) | 
            <!-- Navigation links to key sections -->
            <a href="main_dashboard.php" style="color: #f1c40f; margin-right: 10px;">Main Dashboard</a>
            <a href="staff_list.php" style="color: #f1c40f; margin-right: 10px;">Staff List</a>
            <a href="staff_logout.php" style="color: #f1c40f;">Logout</a>
        </div>

        <!-- Dashboard header with welcome message and system name -->
        <div class="dashboard-header">
            <h1 class="welcome-text">Future Billionaire Academy</h1>
            <p class="lead">Staff Management System Dashboard</p>
        </div>

        <!-- Statistics and Quick Actions Row -->
        <div class="row mb-4">
            <!-- Statistics Cards Column -->
            <div class="col-md-8">
                <div class="row">
                    <!-- Total Staff Statistics Card -->
                    <div class="col-md-6 mb-4">
                        <div class="glass-card stat-card text-center">
                            <i class="fas fa-users stat-icon"></i>
                            <h3><?php echo $totalStaffCount; ?></h3>
                            <p>Total Active Staff</p>
                        </div>
                    </div>
                    
                    <!-- Pending Approvals Statistics Card (Admin only) -->
                    <?php if ($isAdmin): ?>
                    <div class="col-md-6 mb-4">
                        <div class="glass-card stat-card text-center">
                            <i class="fas fa-user-clock stat-icon"></i>
                            <h3><?php echo $pendingUsersCount; ?></h3>
                            <p>Pending Approvals</p>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <!-- System Status Statistics Card -->
                    <div class="col-md-6 mb-4">
                        <div class="glass-card stat-card text-center">
                            <i class="fas fa-check-circle stat-icon" style="color: #2ecc71;"></i>
                            <h3>Online</h3>
                            <p>System Status</p>
                        </div>
                    </div>
                    
                    <!-- Recent Activity Statistics Card -->
                    <div class="col-md-6 mb-4">
                        <div class="glass-card stat-card text-center">
                            <i class="fas fa-chart-line stat-icon"></i>
                            <h3><?php echo count($recentActivity); ?></h3>
                            <p>Recent Logins</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions Panel Column -->
            <div class="col-md-4">
                <div class="glass-card">
                    <h4 class="mb-3"><i class="fas fa-bolt me-2"></i>Quick Actions</h4>
                    
                    <!-- Main Dashboard Quick Action -->
                    <a href="main_dashboard.php" class="quick-action">
                        <i class="fas fa-home me-2"></i>Main Dashboard
                    </a>
                    
                    <!-- Staff List Quick Action -->
                    <a href="staff_list.php" class="quick-action">
                        <i class="fas fa-list me-2"></i>View All Staff
                    </a>
                    
                    <?php if ($isAdmin): ?>
                    <!-- Add New Staff Quick Action (Admin only) -->
                    <a href="staff_create.php" class="quick-action">
                        <i class="fas fa-user-plus me-2"></i>Add New Staff
                    </a>
                    
                    <!-- Pending Approvals Quick Action (Admin only, shows when there are pending approvals) -->
                    <?php if ($pendingUsersCount > 0): ?>
                    <a href="staff_pending_approvals.php" class="quick-action" style="background: rgba(231, 76, 60, 0.3);">
                        <i class="fas fa-exclamation-circle me-2"></i>Review Pending Approvals
                    </a>
                    <?php endif; ?>
                    <?php endif; ?>
                    
                    <!-- My Profile Quick Action -->
                    <a href="staff_profile.php" class="quick-action">
                        <i class="fas fa-user-cog me-2"></i>My Profile
                    </a>
                </div>
            </div>
        </div>

        <!-- Recent Activity and System Information Row -->
        <div class="row">
            <!-- Recent Activity Panel Column -->
            <div class="col-md-8 mb-4">
                <div class="glass-card">
                    <h4 class="mb-3"><i class="fas fa-history me-2"></i>Recent Activity</h4>
                    
                    <?php if (!empty($recentActivity)): ?>
                        <ul class="activity-list">
                            <?php foreach ($recentActivity as $activity): ?>
                                <li class="activity-item">
                                    <div class="d-flex justify-content-between">
                                        <span>
                                            <i class="fas fa-user me-2"></i>
                                            <?php echo htmlspecialchars($activity['Username']); ?>
                                        </span>
                                        <span class="text-muted">
                                            <?php 
                                            // Format last login date or show 'Never' if no login recorded
                                            if ($activity['LastLogin']) {
                                                echo date('M j, Y g:i A', strtotime($activity['LastLogin']));
                                            } else {
                                                echo 'Never';
                                            }
                                            ?>
                                        </span>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <!-- Empty state message when no activity exists -->
                        <p class="text-center text-muted py-3">No recent activity to display.</p>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- System Information Panel Column -->
            <div class="col-md-4 mb-4">
                <div class="glass-card">
                    <h4 class="mb-3"><i class="fas fa-info-circle me-2"></i>System Information</h4>
                    
                    <!-- Last Login Information -->
                    <div class="mb-3">
                        <small class="text-muted">Last Login</small>
                        <div>
                            <i class="fas fa-calendar me-2"></i>
                            <?php 
                            // Display last activity timestamp or 'First login' if not set
                            if (isset($_SESSION['LAST_ACTIVITY'])) {
                                echo date('M j, Y g:i A', $_SESSION['LAST_ACTIVITY']);
                            } else {
                                echo 'First login';
                            }
                            ?>
                        </div>
                    </div>
                    
                    <!-- User Role Information -->
                    <div class="mb-3">
                        <small class="text-muted">Your Role</small>
                        <div>
                            <i class="fas fa-user-tag me-2"></i>
                            <?php echo htmlspecialchars($_SESSION['role'] ?? 'Not set'); ?>
                        </div>
                    </div>
                    
                    <!-- Additional Navigation Section -->
                    <div class="mt-4 pt-3 border-top">
                        <small class="text-muted">Navigation</small>
                        <div>
                            <a href="main_dashboard.php" class="btn btn-sm btn-outline-light w-100 mt-2">
                                <i class="fas fa-home me-1"></i> Main Dashboard
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Include Bootstrap JavaScript for interactive components -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>