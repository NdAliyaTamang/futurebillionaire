<?php
// Include required files for authentication, staff model, and database connection
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/staff_model.php';
require_once __DIR__ . '/../includes/db.php';

// Restrict access to Admins only - security check
if ($_SESSION['role'] !== 'Admin') {
    die("Access denied. Admin only.");
}

// Validate staff ID from URL parameter
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    // Redirect to staff list if invalid or missing ID
    header("Location: staff_list.php");
    exit();
}

// Initialize staff model and retrieve staff data
$staffModel = new StaffModel();
$staffId = (int)$_GET['id'];
$staff = $staffModel->getStaffById($staffId);

// Check if staff member exists
if (!$staff) {
    $_SESSION['error_message'] = "Staff member not found";
    header("Location: staff_list.php");
    exit();
}

// Get available departments for dropdown
$departments = $staffModel->getDepartments();
$errors = [];

// Process form submission for updating staff member
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect and sanitize form data
    $data = [
        'FirstName' => trim($_POST['FirstName']),
        'LastName' => trim($_POST['LastName']),
        'Email' => trim($_POST['Email']),
        'Department' => trim($_POST['Department']),
        'Salary' => trim($_POST['Salary']),
        'HireDate' => trim($_POST['HireDate']),
        'IsActive' => (int)$_POST['IsActive'] // Convert to integer for database
    ];

    // Validate required fields
    if (empty($data['FirstName'])) $errors[] = "First name is required";
    if (empty($data['LastName'])) $errors[] = "Last name is required";
    if (empty($data['Email'])) $errors[] = "Email is required";
    if (empty($data['Department'])) $errors[] = "Department is required";
    if (empty($data['HireDate'])) $errors[] = "Hire date is required";

    // If no validation errors, proceed with update
    if (empty($errors)) {
        try {
            // Update staff record in database
            $staffModel->updateStaff($staffId, $data);
            $_SESSION['success_message'] = "Staff member updated successfully!";
            header("Location: staff_list.php");
            exit();
        } catch (Exception $e) {
            // Catch and display any database errors
            $errors[] = $e->getMessage();
        }
    }
} else {
    // Pre-populate form with existing staff data for GET request
    $data = $staff;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Staff Member</title>
    <!-- Bootstrap CSS for responsive styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Main page styling with gradient background */
        body {
            font-family: "Poppins", sans-serif;
            background: linear-gradient(135deg, #182848, #4b6cb7);
            color: white;
            min-height: 100vh;
            padding: 30px;
        }
        /* Glass morphism container for form */
        .container {
            background: rgba(255,255,255,0.1);
            border-radius: 15px;
            padding: 30px;
            max-width: 800px;
            margin: auto;
            box-shadow: 0 8px 25px rgba(0,0,0,0.3);
        }
        /* Header styling with accent color */
        h1 { color: #f1c40f; }
        /* Form label styling */
        label { font-weight: bold; }
        /* Primary button styling */
        .btn-primary { background-color: #2ecc71; border: none; }
        .btn-primary:hover { background-color: #27ae60; }
        /* User info header styling */
        .user-info {
            background: rgba(255, 255, 255, 0.1);
            padding: 10px 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 14px;
            text-align: right;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- User information and navigation header -->
        <div class="user-info">
            Welcome, <strong><?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?></strong> 
            (<?php echo htmlspecialchars($_SESSION['role'] ?? 'Staff'); ?>) | 
            <a href="staff_list.php" style="color: #f1c40f; margin-right: 10px;">Staff List</a>
            <a href="staff_logout.php" style="color: #f1c40f;">Logout</a>
        </div>

        <!-- Page header with back button -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1>Edit Staff Member</h1>
            <a href="staff_list.php" class="btn btn-secondary">Back to List</a>
        </div>

        <!-- Display validation errors if any -->
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <strong>Errors:</strong>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= htmlspecialchars($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Staff information display (read-only fields) -->
        <div class="mb-4 p-3 bg-dark bg-opacity-25 rounded">
            <h4>Staff Information</h4>
            <p><strong>ID:</strong> #<?= htmlspecialchars($staff['StaffID']); ?></p>
            <p><strong>Username:</strong> <?= htmlspecialchars($staff['Username']); ?></p>
            <p><strong>User ID:</strong> <?= htmlspecialchars($staff['UserID']); ?></p>
            <p><strong>Role:</strong> <?= htmlspecialchars($staff['Role']); ?></p>
        </div>

        <!-- Staff edit form -->
        <form method="POST">
            <div class="row g-3">
                <!-- First name field -->
                <div class="col-md-6">
                    <label>First Name *</label>
                    <input type="text" name="FirstName" value="<?= htmlspecialchars($data['FirstName']); ?>" class="form-control" required>
                </div>
                <!-- Last name field -->
                <div class="col-md-6">
                    <label>Last Name *</label>
                    <input type="text" name="LastName" value="<?= htmlspecialchars($data['LastName']); ?>" class="form-control" required>
                </div>
                <!-- Email field -->
                <div class="col-md-6">
                    <label>Email *</label>
                    <input type="email" name="Email" value="<?= htmlspecialchars($data['Email']); ?>" class="form-control" required>
                </div>
                <!-- Department dropdown -->
                <div class="col-md-6">
                    <label>Department *</label>
                    <select name="Department" class="form-select" required>
                        <option value="">Select Department</option>
                        <?php foreach ($departments as $dept): ?>
                            <option value="<?= htmlspecialchars($dept); ?>" <?= $data['Department'] === $dept ? 'selected' : ''; ?>>
                                <?= htmlspecialchars($dept); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <!-- Salary field -->
                <div class="col-md-6">
                    <label>Salary (DKK)</label>
                    <input type="number" name="Salary" value="<?= htmlspecialchars($data['Salary']); ?>" class="form-control" step="0.01" min="0">
                </div>
                <!-- Hire date field -->
                <div class="col-md-6">
                    <label>Hire Date *</label>
                    <input type="date" name="HireDate" value="<?= htmlspecialchars($data['HireDate']); ?>" class="form-control" required>
                </div>
                <!-- Active status dropdown -->
                <div class="col-md-6">
                    <label>Status</label>
                    <select name="IsActive" class="form-select">
                        <option value="1" <?= $data['IsActive'] ? 'selected' : ''; ?>>Active</option>
                        <option value="0" <?= !$data['IsActive'] ? 'selected' : ''; ?>>Inactive</option>
                    </select>
                </div>
            </div>

            <!-- Form action buttons -->
            <div class="mt-4">
                <button type="submit" class="btn btn-primary">Update Staff</button>
                <a href="staff_list.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>