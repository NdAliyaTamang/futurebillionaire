<?php
// Start session to manage user login state
session_start();

// Include required files for database connection and authentication functions
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth_model.php';

// Initialize variables for error message and username persistence
$error = '';
$username = '';

// Check if form was submitted via POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and retrieve form data
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'Staff';

    // Validate required fields
    if (empty($username) || empty($password)) {
        $error = "Please enter both username and password";
    } else {
        // Verify user credentials against database
        $user = verifyUser($username, $password, $role);
        
        if ($user) {
            // If authentication successful, set session variables
            $_SESSION['userID'] = $user['UserID'];
            $_SESSION['username'] = $user['Username'];
            $_SESSION['role'] = $user['Role'];
            $_SESSION['LAST_ACTIVITY'] = time(); // Track session activity for timeout
            
            // Redirect user to appropriate dashboard based on role
            header("Location: staff_list.php");
            exit(); // Always exit after header redirect to prevent further execution
        } else {
            // Authentication failed - set error message
            $error = "Invalid username, password, or role";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Future Billionaire Academy</title>
    <!-- Bootstrap CSS for responsive styling -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Main background gradient */
        body {
            background: linear-gradient(135deg, #182848, #4b6cb7);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: "Poppins", sans-serif;
        }
        /* Glass morphism effect for login container */
        .login-container {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 40px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            color: white;
        }
        /* Header styling with accent color */
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .login-header h2 {
            color: #f1c40f;
            font-weight: 600;
        }
        /* Custom form control styling */
        .form-control {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.3);
            color: white;
            border-radius: 8px;
            padding: 12px;
        }
        /* Focus state for form inputs */
        .form-control:focus {
            background: rgba(255, 255, 255, 0.15);
            border-color: #f1c40f;
            color: white;
            box-shadow: 0 0 0 0.2rem rgba(241, 196, 15, 0.25);
        }
        /* Placeholder text color */
        .form-control::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }
        /* Login button gradient and hover effects */
        .btn-login {
            background: linear-gradient(135deg, #f1c40f, #f39c12);
            border: none;
            color: #182848;
            font-weight: 600;
            padding: 12px;
            border-radius: 8px;
            width: 100%;
            margin-top: 10px;
        }
        .btn-login:hover {
            background: linear-gradient(135deg, #f39c12, #e67e22);
            color: #182848;
        }
        /* Alert box styling */
        .alert {
            border-radius: 8px;
            border: none;
        }
    </style>
</head>
<body>
    <!-- Main login container -->
    <div class="login-container">
        <div class="login-header">
            <h2>Future Billionaire Academy</h2>
            <p class="mb-0">Staff Portal Login</p>
        </div>

        <!-- Display error message if authentication fails -->
        <?php if ($error): ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <!-- Login form -->
        <form method="POST" action="">
            <!-- Username input field -->
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" 
                       value="<?php echo htmlspecialchars($username); ?>" 
                       placeholder="Enter your username" required>
            </div>

            <!-- Password input field -->
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" 
                       placeholder="Enter your password" required>
            </div>

            <!-- Role selection dropdown -->
            <div class="mb-3">
                <label for="role" class="form-label">Role</label>
                <select class="form-control" id="role" name="role" required>
                    <option value="Staff" <?php echo ($_POST['role'] ?? 'Staff') === 'Staff' ? 'selected' : ''; ?>>Staff</option>
                    <option value="Admin" <?php echo ($_POST['role'] ?? '') === 'Admin' ? 'selected' : ''; ?>>Admin</option>
                </select>
            </div>

            <!-- Submit button -->
            <button type="submit" class="btn btn-login">Login</button>
        </form>

        <!-- Additional information -->
        <div class="text-center mt-3">
            <small class="text-muted">Use your assigned credentials to access the system</small>
        </div>
    </div>
</body>
</html>