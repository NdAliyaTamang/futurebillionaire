<?php
// Include required files for authentication and staff model functionality
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/staff_model.php';

// Initialize staff model for database operations
$staffModel = new StaffModel();

// Get filter values from URL parameters with default empty values
$searchTerm = $_GET['search'] ?? '';
$departmentFilter = $_GET['department'] ?? '';
$statusFilter = $_GET['is_active'] ?? '';

// Build filters array for database query
$filters = [];
if (!empty($searchTerm)) {
    $filters['search'] = $searchTerm; // Add search term to filters
}
if (!empty($departmentFilter)) {
    $filters['department'] = $departmentFilter; // Add department filter
}
if (!empty($statusFilter)) {
    $filters['is_active'] = $statusFilter; // Add status filter (active/inactive)
}

// Get staff data with applied filters from database
$staffMembers = $staffModel->getStaff($filters);
// Get all departments for filter dropdown
$departments = $staffModel->getDepartments();
// Check if current user has admin privileges for role-based access
$isAdmin = ($_SESSION['role'] === 'Admin');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Staff Management</title>
<!-- Include Bootstrap CSS for responsive styling -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Include Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
/* Gradient background with fixed positioning */
body {
  background: linear-gradient(135deg, #212e68ff 0%, #9e69d3ff 100%);
  background-attachment: fixed;
  min-height: 100vh;
  margin: 0;
  padding: 40px;
  font-family: "Poppins", sans-serif;
}
/* Main container styling with gradient and shadow */
.container {
  background: linear-gradient(135deg, #6c8fd6ff, #4b6cb7);
  border-radius: 15px;
  padding: 30px;
  box-shadow: 0 10px 40px rgba(0, 0, 0, 0.4);
  color: white;
}
/* Page header styling */
h1 {
  color: #f1c40f;
  font-weight: 600;
}
/* Search box styling with glass effect */
.search-box {
  background: rgba(255, 255, 255, 0.15);
  border: 2px solid rgba(255, 255, 255, 0.3);
  color: white;
}
.search-box:focus {
  background: rgba(255, 255, 255, 0.2);
  border-color: #f1c40f;
  color: white;
  box-shadow: none;
}
/* Search button styling with gradient */
.btn-search {
  background: linear-gradient(135deg, #f1c40f, #f39c12);
  border: none;
  color: #182848;
  font-weight: 600;
}
/* Form select styling for filter dropdowns */
.form-select {
  background: rgba(255, 255, 255, 0.15);
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: white;
}
.form-select:focus {
  background: rgba(255, 255, 255, 0.2);
  border-color: #f1c40f;
  color: white;
  box-shadow: none;
}
/* Table styling with semi-transparent background */
.table {
  background: rgba(52, 75, 120, 0.8);
  color: #fff;
  border-radius: 10px;
  overflow: hidden;
}
/* Table header styling */
.table thead {
  background-color: rgba(0, 0, 0, 0.4);
  color: #fff;
}
/* Status badge styling for active staff */
.status-badge.active {
  background: #2ecc71;
  color: white;
  padding: 5px 12px;
  border-radius: 8px;
}
/* Status badge styling for inactive staff */
.status-badge.inactive {
  background: #e74c3c;
  color: white;
  padding: 5px 12px;
  border-radius: 8px;
}
/* User info header styling */
.user-info {
  background: rgba(255, 255, 255, 0.1);
  padding: 10px 15px;
  border-radius: 8px;
  margin-bottom: 15px;
  font-size: 14px;
}
/* Filter badge styling for active filters display */
.filter-badge {
  background: rgba(52, 152, 219, 0.3);
  padding: 5px 10px;
  border-radius: 20px;
  margin: 0 5px 5px 0;
  display: inline-block;
}
</style>
</head>
<body>
<div class="container">
  <!-- User info header with navigation -->
  <div class="user-info d-flex justify-content-between align-items-center">
    <div><strong>Future Billionaire Academy</strong> | Staff Portal</div>
    <div>
      Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong> 
      (<?php echo htmlspecialchars($_SESSION['role']); ?>) | 
      <!-- Dashboard navigation link -->
      <a href="staff_dashboard.php" style="color: #f1c40f; margin-right: 10px;">Dashboard</a>
      <!-- Logout link -->
      <a href="staff_logout.php" style="color: #f1c40f;">Logout</a>
    </div>
  </div>

  <!-- Page header with title and add staff button for admins -->
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h1><i class="fas fa-users me-2"></i>Staff Directory</h1>
    <?php if ($isAdmin): ?>
      <!-- Add new staff button - only visible to admins -->
      <a href="staff_create.php" class="btn btn-success"><i class="fas fa-user-plus me-2"></i>Add New Staff</a>
    <?php endif; ?>
  </div>

  <!-- Search and Filter Section -->
  <div class="bg-dark bg-opacity-25 p-4 rounded mb-4">
    <h5 class="text-warning mb-3"><i class="fas fa-search me-2"></i>Search & Filter</h5>
    
    <!-- Search and filter form using GET method for URL parameters -->
    <form method="GET" class="row g-3 align-items-center">
      <!-- Search input field -->
      <div class="col-md-4">
        <input type="text" name="search" class="form-control search-box form-control-lg" 
               placeholder="Search by name or email..." 
               value="<?= htmlspecialchars($searchTerm); ?>">
      </div>
      
      <!-- Department filter dropdown -->
      <div class="col-md-3">
        <select name="department" class="form-select form-select-lg">
          <option value="">All Departments</option>
          <?php foreach ($departments as $dept): ?>
            <option value="<?= htmlspecialchars($dept); ?>" <?= $departmentFilter === $dept ? 'selected' : ''; ?>>
              <?= htmlspecialchars($dept); ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      
      <!-- Status filter dropdown -->
      <div class="col-md-2">
        <select name="is_active" class="form-select form-select-lg">
          <option value="">All Status</option>
          <option value="1" <?= $statusFilter === '1' ? 'selected' : ''; ?>>Active</option>
          <option value="0" <?= $statusFilter === '0' ? 'selected' : ''; ?>>Inactive</option>
        </select>
      </div>
      
      <!-- Action buttons for search and clear -->
      <div class="col-md-3">
        <div class="d-flex gap-2">
          <button type="submit" class="btn btn-search btn-lg flex-fill"><i class="fas fa-search me-2"></i>Search</button>
          <a href="staff_list.php" class="btn btn-outline-light btn-lg flex-fill">Clear</a>
        </div>
      </div>
    </form>

    <!-- Active Filters Display - Shows currently applied filters -->
    <?php if (!empty($searchTerm) || !empty($departmentFilter) || !empty($statusFilter)): ?>
      <div class="mt-3">
        <small class="text-warning">Active Filters:</small>
        <?php if (!empty($searchTerm)): ?>
          <span class="filter-badge">Search: "<?= htmlspecialchars($searchTerm); ?>"</span>
        <?php endif; ?>
        <?php if (!empty($departmentFilter)): ?>
          <span class="filter-badge">Department: <?= htmlspecialchars($departmentFilter); ?></span>
        <?php endif; ?>
        <?php if (!empty($statusFilter)): ?>
          <span class="filter-badge">Status: <?= $statusFilter === '1' ? 'Active' : 'Inactive'; ?></span>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </div>

  <!-- Staff Table for displaying results -->
  <div class="table-responsive">
    <table class="table table-bordered align-middle">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Department</th>
          <th>Hire Date</th>
          <?php if ($isAdmin): ?><th>Salary</th><?php endif; ?> <!-- Salary column only for admins -->
          <th>Status</th>
          <?php if ($isAdmin): ?><th>Actions</th><?php endif; ?> <!-- Action buttons only for admins -->
        </tr>
      </thead>
      <tbody>
        <?php if (empty($staffMembers)): ?>
          <!-- Empty state message when no staff members found -->
          <tr>
            <td colspan="<?= $isAdmin ? 8 : 6; ?>" class="text-center py-4">
              <i class="fas fa-users fa-2x mb-3 text-muted"></i>
              <h5 class="text-muted">No staff members found</h5>
              <?php if (!empty($searchTerm) || !empty($departmentFilter) || !empty($statusFilter)): ?>
                <!-- Message when filters return no results -->
                <p class="text-muted">Try adjusting your search criteria or <a href="staff_list.php" class="text-warning">clear filters</a></p>
              <?php else: ?>
                <!-- Message when no staff members exist in system -->
                <p class="text-muted">No staff members are currently in the system</p>
              <?php endif; ?>
            </td>
          </tr>
        <?php else: ?>
          <!-- Loop through each staff member and display in table rows -->
          <?php foreach ($staffMembers as $staff): ?>
            <tr>
              <td><?= $staff['StaffID']; ?></td>
              <td><?= htmlspecialchars($staff['FirstName'] . ' ' . $staff['LastName']); ?></td>
              <td><?= htmlspecialchars($staff['Email']); ?></td>
              <td><?= htmlspecialchars($staff['Department']); ?></td>
              <td><?= date('M d, Y', strtotime($staff['HireDate'])); ?></td>
              <?php if ($isAdmin): ?>
                <!-- Salary information - only visible to admins -->
                <td><?= $staff['Salary'] ? number_format($staff['Salary'], 2) . ' DKK' : 'N/A'; ?></td>
              <?php endif; ?>
              <td>
                <!-- Status badge with color coding -->
                <span class="status-badge <?= $staff['IsActive'] ? 'active' : 'inactive'; ?>">
                  <?= $staff['IsActive'] ? 'Active' : 'Inactive'; ?>
                </span>
              </td>
              <?php if ($isAdmin): ?>
                <!-- Action buttons for edit and delete - only visible to admins -->
                <td>
                  <a href="staff_edit.php?id=<?= $staff['StaffID']; ?>" class="btn btn-warning btn-sm">Edit</a>
                  <a href="staff_delete.php?id=<?= $staff['StaffID']; ?>" class="btn btn-danger btn-sm">Delete</a>
                </td>
              <?php endif; ?>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Staff count summary at bottom of page -->
  <div class="mt-3 text-warning">
    <i class="fas fa-users me-2"></i>Total Staff: <?= count($staffMembers); ?>
    <?php if (!empty($searchTerm) || !empty($departmentFilter) || !empty($statusFilter)): ?>
      <!-- Indicate when results are filtered -->
      <small class="text-muted">(filtered results)</small>
    <?php endif; ?>
  </div>
</div>

<!-- Include Bootstrap JavaScript for interactive components -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>