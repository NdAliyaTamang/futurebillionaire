<?php
// Enable error reporting for debugging (should be disabled in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include required files for authentication, database, and models
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth_model.php';

// Check if current user has Admin privileges
if ($_SESSION['role'] !== 'Admin') {
    die("Access denied. Admin only.");
}

// Initialize database connection and error array
$pdo = getDB();
$errors = [];

// Load department names from database dynamically
try {
    // Query distinct department names from Staff table
    $deptStmt = $pdo->query("SELECT DISTINCT Department FROM Staff WHERE Department IS NOT NULL ORDER BY Department");
    $departments = $deptStmt->fetchAll(PDO::FETCH_COLUMN);
    // Fallback to default departments if none found in database
    if (empty($departments)) {
        $departments = ["Computer Science", "Physics", "Chemistry", "Mathematics", "English", "Biology", "Economics"];
    }
} catch (PDOException $e) {
    // If database query fails, use default department list
    $departments = ["Computer Science", "Physics", "Chemistry", "Mathematics", "English"];
}

// Process form submission when POST request is received
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and normalize form data (convert keys to lowercase)
    $data = [];
    foreach ($_POST as $key => $value) {
        $data[strtolower($key)] = trim($value);
    }

    // Validate required fields
    if (empty($data['username'])) $errors[] = "Username is required.";
    if (empty($data['password'])) $errors[] = "Password is required.";
    if (empty($data['firstname'])) $errors[] = "First name is required.";
    if (empty($data['lastname'])) $errors[] = "Last name is required.";
    if (empty($data['email'])) $errors[] = "Email is required.";
    if (empty($data['department'])) $errors[] = "Department is required.";
    if (empty($data['hiredate'])) $errors[] = "Hire date is required.";

    // If no validation errors, proceed with database operations
    if (empty($errors)) {
        try {
            // Check if username already exists in User table
            $checkUser = $pdo->prepare("SELECT COUNT(*) FROM User WHERE Username = ?");
            $checkUser->execute([$data['username']]);
            if ($checkUser->fetchColumn() > 0) {
                throw new Exception("Username already exists. Please choose another one.");
            }

            // Check if email already exists in Staff table
            $checkEmail = $pdo->prepare("SELECT COUNT(*) FROM Staff WHERE Email = ?");
            $checkEmail->execute([$data['email']]);
            if ($checkEmail->fetchColumn() > 0) {
                throw new Exception("Email already exists. Please use a different one.");
            }

            // Create user account in User table using auth_model function
            $userId = createUser($data['username'], $data['password'], 'Staff');
            if (!$userId) {
                throw new Exception("Failed to create user. Please try again.");
            }

            // Insert staff record with user information
            $salary = !empty($data['salary']) && is_numeric($data['salary']) ? floatval($data['salary']) : 0.00;
            $stmt = $pdo->prepare("
                INSERT INTO Staff (UserID, FirstName, LastName, Email, Department, Salary, HireDate, IsActive)
                VALUES (?, ?, ?, ?, ?, ?, ?, 1)
            ");
            $stmt->execute([
                $userId,
                ucfirst($data['firstname']), // Capitalize first name
                ucfirst($data['lastname']),  // Capitalize last name
                $data['email'],
                $data['department'],
                $salary, // Convert to float for database
                $data['hiredate']
            ]);

            // Set success message and redirect to staff list
            $_SESSION['success_message'] = " Staff member '{$data['firstname']} {$data['lastname']}' created successfully!";
            header("Location: staff_list.php");
            exit();

        } catch (Exception $e) {
            // Catch any exceptions and add to errors array for display
            $errors[] = $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Staff - Future Billionaire Academy</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        /* Main page styling with gradient background */
        body {
            font-family: "Poppins", sans-serif;
            background: linear-gradient(135deg, #182848, #4b6cb7);
            color: white;
            margin: 0;
            padding: 0;
        }
        /* Glass morphism container for form */
        .container {
            background: rgba(255,255,255,0.08);
            padding: 30px;
            border-radius: 12px;
            width: 85%;
            max-width: 800px;
            margin: 50px auto;
            box-shadow: 0 5px 25px rgba(0,0,0,0.3);
        }
        /* Header styling */
        h1 {
            text-align: center;
            color: #f1c40f;
            margin-bottom: 20px;
        }
        /* Form label styling */
        label {
            display: block;
            margin-top: 12px;
            color: #f1f1f1;
        }
        /* Input and select field styling */
        input, select {
            width: 100%;
            padding: 10px;
            border-radius: 6px;
            border: none;
            margin-top: 5px;
            font-size: 15px;
        }
        /* Focus state for form elements */
        input:focus, select:focus {
            outline: 2px solid #f1c40f;
        }
        /* Primary button styling */
        .btn {
            display: inline-block;
            text-decoration: none;
            background-color: #27ae60;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            margin-top: 15px;
        }
        /* Button hover effects */
        .btn:hover {
            background-color: #1e8449;
        }
        /* Outline button variant */
        .btn-outline {
            background: none;
            border: 2px solid #f1c40f;
            color: #f1c40f;
        }
        .btn-outline:hover {
            background-color: #f1c40f;
            color: #182848;
        }
        /* Error alert styling */
        .alert-danger {
            background-color: rgba(231, 76, 60, 0.9);
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 15px;
        }
        /* Form group spacing */
        .form-group {
            margin-bottom: 15px;
        }
        /* User info header styling */
        .user-info {
            background: rgba(255, 255, 255, 0.1);
            padding: 10px 15px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 14px;
            text-align: right;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- User information and navigation header -->
        <div class="user-info">
            Welcome, <strong><?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?></strong> 
            (<?php echo htmlspecialchars($_SESSION['role'] ?? 'Staff'); ?>) | 
            <a href="staff_list.php" style="color: #f1c40f; margin-right: 10px;">Staff List</a>
            <a href="staff_logout.php" style="color: #f1c40f;">Logout</a>
        </div>

        <h1>Add New Staff Member</h1>
        <!-- Back navigation button -->
        <a href="staff_list.php" class="btn btn-outline">← Back to Staff List</a>

        <!-- Display validation errors if any -->
        <?php if (!empty($errors)): ?>
            <div class="alert-danger">
                <h3> Please fix the following errors:</h3>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Staff creation form -->
        <form method="POST">
            <!-- Username field -->
            <div class="form-group">
                <label>Username *</label>
                <input type="text" name="Username" required>
            </div>

            <!-- Password field -->
            <div class="form-group">
                <label>Password *</label>
                <input type="password" name="Password" required>
            </div>

            <!-- First name field -->
            <div class="form-group">
                <label>First Name *</label>
                <input type="text" name="FirstName" required>
            </div>

            <!-- Last name field -->
            <div class="form-group">
                <label>Last Name *</label>
                <input type="text" name="LastName" required>
            </div>

            <!-- Email field -->
            <div class="form-group">
                <label>Email *</label>
                <input type="email" name="Email" required>
            </div>

            <!-- Department dropdown (dynamically populated) -->
            <div class="form-group">
                <label>Department *</label>
                <select name="Department" required>
                    <option value="">Select Department</option>
                    <?php foreach ($departments as $dept): ?>
                        <option value="<?php echo htmlspecialchars($dept); ?>">
                            <?php echo htmlspecialchars($dept); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Salary field (optional) -->
            <div class="form-group">
                <label>Salary (DKK)</label>
                <input type="number" name="Salary" min="0" step="0.01">
            </div>

            <!-- Hire date field (defaults to current date) -->
            <div class="form-group">
                <label>Hire Date *</label>
                <input type="date" name="HireDate" value="<?php echo date('Y-m-d'); ?>" required>
            </div>

            <!-- Form action buttons -->
            <button type="submit" class="btn">Create Staff Member</button>
            <a href="staff_list.php" class="btn btn-outline">Cancel</a>
        </form>
    </div>
</body>
</html>