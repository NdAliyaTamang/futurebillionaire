<?php
// Include database connection file
require_once 'db.php';

/* =====================================
   STAFF MODEL (Class-based + Functions)
   Handles all database operations for staff management
   Uses prepared statements to prevent SQL injection
===================================== */

class StaffModel {
    private $db;

    // Constructor - initializes database connection
    public function __construct() {
        $this->db = getDB();
    }

    /**
     * Get staff members with optional filtering
     * @param array $filters - Optional filters for department, status, and search
     * @return array - List of staff members or empty array on error
     */
    public function getStaff($filters = []) {
        // Base SQL query with JOIN to get user information
        $sql = "SELECT s.*, u.Username 
                FROM Staff s 
                JOIN User u ON s.UserID = u.UserID 
                WHERE 1=1";  // 1=1 for easier WHERE clause building
        $params = [];

        // Add department filter if provided
        if (!empty($filters['department'])) {
            $sql .= " AND s.Department = ?";
            $params[] = $filters['department'];
        }

        // Add active status filter if provided
        if (!empty($filters['is_active'])) {
            $sql .= " AND s.IsActive = ?";
            $params[] = $filters['is_active'];
        }

        // Add search filter for name or email
if (!empty($filters['search'])) {
    $sql .= " AND (s.FirstName LIKE ? OR s.LastName LIKE ? OR s.Email LIKE ? OR CONCAT(s.FirstName, ' ', s.LastName) LIKE ?)";
    $searchTerm = "%{$filters['search']}%";  // Wildcard search
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $params[] = $searchTerm;
}

        // Order results by last name, then first name
        $sql .= " ORDER BY s.LastName, s.FirstName";

        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            // Log error but return empty array to avoid breaking the application
            error_log("StaffModel::getStaff Error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get a single staff member by ID
     * @param int $id - Staff ID to retrieve
     * @return array|null - Staff data or null if not found/error
     */
    public function getStaffById($id) {
        $sql = "SELECT s.*, u.Username, u.Role 
                FROM Staff s 
                JOIN User u ON s.UserID = u.UserID 
                WHERE s.StaffID = ?";
        
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute([$id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("StaffModel::getStaffById Error: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Create a new staff record
     * @param array $data - Staff data including UserID, names, email, etc.
     * @return int - Last insert ID on success
     * @throws Exception - On database error
     */
    public function createStaff($data) {
        $sql = "INSERT INTO Staff (UserID, FirstName, LastName, Email, Department, Salary, IsActive, HireDate) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                $data['UserID'],
                $data['FirstName'],
                $data['LastName'],
                $data['Email'],
                $data['Department'],
                $data['Salary'] ?? null,  // Use null if not provided
                $data['IsActive'] ?? 1,   // Default to active
                $data['HireDate']
            ]);
            return $this->db->lastInsertId();
        } catch (PDOException $e) {
            throw new Exception("Failed to create staff: " . $e->getMessage());
        }
    }

    /**
     * Update an existing staff member
     * @param int $id - Staff ID to update
     * @param array $data - Updated staff data
     * @return bool - True on success
     * @throws Exception - On database error
     */
    public function updateStaff($id, $data) {
        $sql = "UPDATE Staff SET 
                FirstName = ?, LastName = ?, Email = ?, Department = ?, 
                Salary = ?, IsActive = ?, HireDate = ? 
                WHERE StaffID = ?";
        
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute([
                $data['FirstName'],
                $data['LastName'],
                $data['Email'],
                $data['Department'],
                $data['Salary'],
                $data['IsActive'],
                $data['HireDate'],
                $id
            ]);
            return true;
        } catch (PDOException $e) {
            throw new Exception("Failed to update staff: " . $e->getMessage());
        }
    }

    /**
     * Deactivate a staff member (soft delete)
     * @param int $id - Staff ID to deactivate
     * @return bool - True on success
     * @throws Exception - On database error
     */
    public function deactivateStaff($id) {
        $sql = "UPDATE Staff SET IsActive = 0 WHERE StaffID = ?";
        try {
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([$id]);
        } catch (PDOException $e) {
            throw new Exception("Failed to deactivate staff: " . $e->getMessage());
        }
    }

    /**
     * Activate a staff member
     * @param int $id - Staff ID to activate
     * @return bool - True on success
     * @throws Exception - On database error
     */
    public function activateStaff($id) {
        $sql = "UPDATE Staff SET IsActive = 1 WHERE StaffID = ?";
        try {
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([$id]);
        } catch (PDOException $e) {
            throw new Exception("Failed to activate staff: " . $e->getMessage());
        }
    }

    /**
     * Get all unique departments from staff table
     * @return array - List of departments or default list on error
     */
    public function getDepartments() {
        $sql = "SELECT DISTINCT Department FROM Staff WHERE Department IS NOT NULL ORDER BY Department";
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_COLUMN);
        } catch (PDOException $e) {
            // Return default departments if database query fails
            return ['Mathematics', 'Science', 'English', 'History', 'Arts', 'Computer Science'];
        }
    }

    /**
     * Get available users who can be assigned as staff
     * @return array - List of active staff users
     */
    public function getAvailableUsers() {
        $sql = "SELECT UserID, Username FROM User WHERE IsActive = 1 AND Role = 'Staff'";
        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            return [];
        }
    }
}

/* =====================================
   LEGACY HELPER FUNCTIONS (for Courses)
   Maintained for backward compatibility
   Used by existing course management files
===================================== */

/**
 * Get all active staff members (legacy function)
 * Used by course_edit.php and course_create.php
 * @return array - All active staff members
 */
function getAllStaff() {
    $pdo = getDB();
    $stmt = $pdo->query("SELECT StaffID, FirstName, LastName, Department, Email FROM Staff WHERE IsActive = 1 ORDER BY LastName ASC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Alias for getAllStaff() for backward compatibility
 * @return array - All active staff members
 */
function getStaff() {
    return getAllStaff();
}

/**
 * Get single staff member by ID (legacy function)
 * @param int $id - Staff ID
 * @return array - Staff data or false if not found
 */
function getStaffById($id) {
    $pdo = getDB();
    $stmt = $pdo->prepare("SELECT * FROM Staff WHERE StaffID = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
?>