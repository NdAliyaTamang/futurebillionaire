<?php
/* Include session check to ensure the user is logged in */
include 'check_session.php';

/* Include database configuration to connect to MySQL */
include 'config.php';

/* Get student ID from URL, default to 0 if not set */
$student_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

/* Initialize message variables */
$message = '';
$message_type = '';

/* Redirect if no valid student ID is provided */
if ($student_id == 0) {
    header('Location: index.php');
    exit();
}

/* Handle form submission for updating student data */
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    /* Sanitize all input fields to prevent SQL injection */
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $date_of_birth = mysqli_real_escape_string($conn, $_POST['date_of_birth']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $enrollment_date = mysqli_real_escape_string($conn, $_POST['enrollment_date']);
    $gpa = mysqli_real_escape_string($conn, $_POST['gpa']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $grade_level = mysqli_real_escape_string($conn, $_POST['grade_level']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);

    /* Check if the submitted email exists for another student */
    $check_email = "SELECT * FROM students WHERE email = '$email' AND student_id != $student_id";
    $result = mysqli_query($conn, $check_email);

    /* Set error message if duplicate email found, else update student */
    if (mysqli_num_rows($result) > 0) {
        $message = 'Error: Email already exists for another student!';
        $message_type = 'error';
    } else {
        /* Update student information in the database */
        $update_query = "UPDATE students SET 
                        first_name = '$first_name',
                        last_name = '$last_name',
                        email = '$email',
                        date_of_birth = '$date_of_birth',
                        phone = '$phone',
                        address = '$address',
                        enrollment_date = '$enrollment_date',
                        gpa = '$gpa',
                        status = '$status',
                        grade_level = '$grade_level',
                        gender = '$gender'
                        WHERE student_id = $student_id";
        
        if (mysqli_query($conn, $update_query)) {
            $message = 'Student information updated successfully!';
            $message_type = 'success';
        } else {
            $message = 'Error: ' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
}

/* Fetch current student data to populate the form */
$query = "SELECT * FROM students WHERE student_id = $student_id";
$result = mysqli_query($conn, $query);

/* Redirect if student not found */
if (mysqli_num_rows($result) == 0) {
    header('Location: index.php');
    exit();
}

/* Store fetched student data in an array */
$student = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student - <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📚 Student Management System</h1>
            <p>Developed by Mithil - Future Billionaire Team</p>
            <div style="margin-top: 15px; display: flex; justify-content: center; align-items: center; gap: 15px;">
                <span style="background: rgba(255,255,255,0.2); padding: 8px 20px; border-radius: 20px; font-size: 0.95em;">
                    👤 Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
                </span>
                <a href="logout.php" style="background: rgba(255,255,255,0.9); color: #667eea; padding: 8px 20px; border-radius: 20px; text-decoration: none; font-weight: 600; font-size: 0.9em; transition: all 0.3s;" onmouseover="this.style.background='white'" onmouseout="this.style.background='rgba(255,255,255,0.9)'">
                    🚪 Logout
                </a>
            </div>
        </div>

        <div class="navigation">
            <ul class="nav-links">
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="add_student.php">Add Student</a></li>
                <li><a href="view_students.php">View All Students</a></li>
            </ul>
        </div>

        <div class="content">
            <h2 style="margin-bottom: 20px; color: #495057;">✏️ Edit Student Information</h2>

            <?php if($message): ?>
                <div class="alert alert-<?php echo $message_type; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <div class="form-container">
                <div style="text-align: center; margin-bottom: 20px;">
                    <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; margin: 0 auto 10px; display: flex; align-items: center; justify-content: center; color: white; font-size: 2em; font-weight: bold;">
                        <?php echo strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1)); ?>
                    </div>
                    <p style="color: #6c757d;">Student ID: <?php echo $student['student_id']; ?></p>
                </div>

                <form method="POST" action="">
                    <h3 style="margin-bottom: 20px; color: #667eea;">Personal Information</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="first_name">First Name *</label>
                            <input type="text" id="first_name" name="first_name" value="<?php echo htmlspecialchars($student['first_name']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="last_name">Last Name *</label>
                            <input type="text" id="last_name" name="last_name" value="<?php echo htmlspecialchars($student['last_name']); ?>" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="email">Email Address *</label>
                            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($student['email']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($student['phone']); ?>">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="date_of_birth">Date of Birth *</label>
                            <input type="date" id="date_of_birth" name="date_of_birth" value="<?php echo $student['date_of_birth']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="gender">Gender *</label>
                            <select id="gender" name="gender" required>
                                <option value="Male" <?php echo $student['gender'] == 'Male' ? 'selected' : ''; ?>>Male</option>
                                <option value="Female" <?php echo $student['gender'] == 'Female' ? 'selected' : ''; ?>>Female</option>
                                <option value="Other" <?php echo $student['gender'] == 'Other' ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="address">Address</label>
                        <textarea id="address" name="address" rows="3"><?php echo htmlspecialchars($student['address']); ?></textarea>
                    </div>

                    <h3 style="margin: 30px 0 20px; color: #667eea;">Academic Information</h3>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="grade_level">Grade Level *</label>
                            <select id="grade_level" name="grade_level" required>
                                <option value="Grade 9" <?php echo $student['grade_level'] == 'Grade 9' ? 'selected' : ''; ?>>Grade 9</option>
                                <option value="Grade 10" <?php echo $student['grade_level'] == 'Grade 10' ? 'selected' : ''; ?>>Grade 10</option>
                                <option value="Grade 11" <?php echo $student['grade_level'] == 'Grade 11' ? 'selected' : ''; ?>>Grade 11</option>
                                <option value="Grade 12" <?php echo $student['grade_level'] == 'Grade 12' ? 'selected' : ''; ?>>Grade 12</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="enrollment_date">Enrollment Date *</label>
                            <input type="date" id="enrollment_date" name="enrollment_date" value="<?php echo $student['enrollment_date']; ?>" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="gpa">GPA (0.00 - 4.00) *</label>
                            <input type="number" id="gpa" name="gpa" step="0.01" min="0" max="4" value="<?php echo $student['gpa']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="status">Status *</label>
                            <select id="status" name="status" required>
                                <option value="active" <?php echo $student['status'] == 'active' ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive" <?php echo $student['status'] == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                <option value="graduated" <?php echo $student['status'] == 'graduated' ? 'selected' : ''; ?>>Graduated</option>
                                <option value="suspended" <?php echo $student['status'] == 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                            </select>
                        </div>
                    </div>

                    <div style="margin-top: 30px; display: flex; gap: 15px; justify-content: center;">
                        <button type="submit" class="btn btn-success">Update Student</button>
                        <a href="view_student.php?id=<?php echo $student_id; ?>" class="btn btn-primary">View Profile</a>
                        <a href="view_students.php" class="btn btn-danger">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>

<?php 
/* Close database connection after all operations */
mysqli_close($conn); 
?>
