<?php
// Include session check to ensure the user is logged in
include 'check_session.php';
// Include database configuration
include 'config.php';

// Get the student ID from the URL, default to 0 if not provided
$student_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Redirect to dashboard if no valid student ID is provided
if ($student_id == 0) {
    header('Location: index.php');
    exit();
}

// Fetch student data from the database
$query = "SELECT * FROM students WHERE student_id = $student_id";
$result = mysqli_query($conn, $query);

// Redirect to dashboard if student not found
if (mysqli_num_rows($result) == 0) {
    header('Location: index.php');
    exit();
}

// Store student information in an array
$student = mysqli_fetch_assoc($result);

// Calculate the student's age based on date of birth
$dob = new DateTime($student['date_of_birth']);
$now = new DateTime();
$age = $now->diff($dob)->y;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Student - <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></title>
    <!-- Link to CSS styles -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <!-- Header Section -->
        <div class="header">
            <h1>📚 Student Management System</h1>
            <p>Developed by Mithil - Future Billionaire Team</p>
            <div style="margin-top: 15px; display: flex; justify-content: center; align-items: center; gap: 15px;">
                <!-- Display logged-in user -->
                <span style="background: rgba(255,255,255,0.2); padding: 8px 20px; border-radius: 20px; font-size: 0.95em;">
                    👤 Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
                </span>
                <!-- Logout button -->
                <a href="logout.php" style="background: rgba(255,255,255,0.9); color: #667eea; padding: 8px 20px; border-radius: 20px; text-decoration: none; font-weight: 600; font-size: 0.9em; transition: all 0.3s;" onmouseover="this.style.background='white'" onmouseout="this.style.background='rgba(255,255,255,0.9)'">
                    🚪 Logout
                </a>
            </div>
        </div>

        <!-- Navigation Menu -->
        <div class="navigation">
            <ul class="nav-links">
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="add_student.php">Add Student</a></li>
                <li><a href="view_students.php">View All Students</a></li>
            </ul>
        </div>

        <!-- Main Content Section -->
        <div class="content">
            <!-- Header with action buttons -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2 style="color: #495057;">👤 Student Profile</h2>
                <div style="display: flex; gap: 10px;">
                    <a href="edit_student.php?id=<?php echo $student_id; ?>" class="btn btn-warning">Edit Profile</a>
                    <a href="view_students.php" class="btn btn-primary">Back to List</a>
                </div>
            </div>

            <!-- Student Profile Card -->
            <div class="form-container" style="max-width: 1000px;">
                <div style="text-align: center; margin-bottom: 30px;">
                    <!-- Initials Avatar -->
                    <div style="width: 120px; height: 120px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; margin: 0 auto 15px; display: flex; align-items: center; justify-content: center; color: white; font-size: 3em; font-weight: bold;">
                        <?php echo strtoupper(substr($student['first_name'], 0, 1) . substr($student['last_name'], 0, 1)); ?>
                    </div>
                    <!-- Student Name -->
                    <h2 style="margin-bottom: 5px; color: #495057;"><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></h2>
                    <!-- Student Status -->
                    <span class="status-badge status-<?php echo $student['status']; ?>" style="font-size: 1em;">
                        <?php echo ucfirst($student['status']); ?>
                    </span>
                </div>

                <!-- Academic Information -->
                <div style="background: #f8f9fa; padding: 25px; border-radius: 10px; margin-bottom: 20px;">
                    <h3 style="color: #667eea; margin-bottom: 20px; text-align: center;">🎓 Academic Information</h3>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; text-align: center;">
                        <div>
                            <div style="color: #6c757d; font-size: 0.9em; margin-bottom: 5px;">Student ID</div>
                            <div style="font-size: 1.5em; font-weight: bold; color: #495057;"><?php echo $student['student_id']; ?></div>
                        </div>
                        <div>
                            <div style="color: #6c757d; font-size: 0.9em; margin-bottom: 5px;">Grade Level</div>
                            <div style="font-size: 1.5em; font-weight: bold; color: #495057;"><?php echo $student['grade_level']; ?></div>
                        </div>
                        <div>
                            <div style="color: #6c757d; font-size: 0.9em; margin-bottom: 5px;">GPA</div>
                            <div style="font-size: 1.5em; font-weight: bold; color: <?php echo $student['gpa'] >= 3.5 ? '#28a745' : ($student['gpa'] >= 2.5 ? '#ffc107' : '#dc3545'); ?>">
                                <?php echo number_format($student['gpa'], 2); ?>
                            </div>
                        </div>
                        <div>
                            <div style="color: #6c757d; font-size: 0.9em; margin-bottom: 5px;">Enrollment Date</div>
                            <div style="font-size: 1.5em; font-weight: bold; color: #495057;">
                                <?php echo date('M d, Y', strtotime($student['enrollment_date'])); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Personal Information -->
                <h3 style="color: #667eea; margin-bottom: 15px;">📋 Personal Information</h3>
                <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
                    <tr style="border-bottom: 1px solid #e9ecef;">
                        <td style="padding: 15px; font-weight: 600; color: #6c757d; width: 200px;">Email Address:</td>
                        <td style="padding: 15px; color: #495057;"><?php echo htmlspecialchars($student['email']); ?></td>
                    </tr>
                    <tr style="border-bottom: 1px solid #e9ecef;">
                        <td style="padding: 15px; font-weight: 600; color: #6c757d;">Phone Number:</td>
                        <td style="padding: 15px; color: #495057;"><?php echo htmlspecialchars($student['phone']); ?></td>
                    </tr>
                    <tr style="border-bottom: 1px solid #e9ecef;">
                        <td style="padding: 15px; font-weight: 600; color: #6c757d;">Date of Birth:</td>
                        <td style="padding: 15px; color: #495057;">
                            <?php echo date('F d, Y', strtotime($student['date_of_birth'])); ?> 
                            <span style="color: #6c757d;">(Age: <?php echo $age; ?> years)</span>
                        </td>
                    </tr>
                    <tr style="border-bottom: 1px solid #e9ecef;">
                        <td style="padding: 15px; font-weight: 600; color: #6c757d;">Gender:</td>
                        <td style="padding: 15px; color: #495057;"><?php echo htmlspecialchars($student['gender']); ?></td>
                    </tr>
                    <tr style="border-bottom: 1px solid #e9ecef;">
                        <td style="padding: 15px; font-weight: 600; color: #6c757d;">Address:</td>
                        <td style="padding: 15px; color: #495057;"><?php echo htmlspecialchars($student['address']); ?></td>
                    </tr>
                    <tr style="border-bottom: 1px solid #e9ecef;">
                        <td style="padding: 15px; font-weight: 600; color: #6c757d;">Record Created:</td>
                        <td style="padding: 15px; color: #495057;"><?php echo date('F d, Y H:i:s', strtotime($student['created_at'])); ?></td>
                    </tr>
                    <tr>
                        <td style="padding: 15px; font-weight: 600; color: #6c757d;">Last Updated:</td>
                        <td style="padding: 15px; color: #495057;"><?php echo date('F d, Y H:i:s', strtotime($student['updated_at'])); ?></td>
                    </tr>
                </table>

                <!-- Action Buttons -->
                <div style="text-align: center; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                    <a href="edit_student.php?id=<?php echo $student_id; ?>" class="btn btn-warning">✏️ Edit Student</a>
                    <a href="delete_student.php?id=<?php echo $student_id; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this student?')">🗑️ Delete Student</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php 
// Close database connection
mysqli_close($conn); 
?>
