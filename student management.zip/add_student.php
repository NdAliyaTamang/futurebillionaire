<?php
/* 
    Include check_session.php to ensure the user is logged in.
    This prevents unauthorized access by verifying active session data.
*/
include 'check_session.php';

/* 
    Include database configuration file.
    This file contains the connection information needed to interact with the database.
*/
include 'config.php';

/* 
    Variables to store success or error messages that will be displayed to the user.
*/
$message = '';
$message_type = '';

/* 
    Check if the current request method is POST.
    This ensures the code only runs when the user submits the form.
*/
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    /* 
        Sanitize and safely process user input using mysqli_real_escape_string.
        This protects the database from SQL injection attacks and removes unsafe characters.
    */
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $date_of_birth = mysqli_real_escape_string($conn, $_POST['date_of_birth']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $enrollment_date = mysqli_real_escape_string($conn, $_POST['enrollment_date']);
    $gpa = mysqli_real_escape_string($conn, $_POST['gpa']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $grade_level = mysqli_real_escape_string($conn, $_POST['grade_level']);
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);

    /* 
        SQL query to check whether the submitted email address 
        already exists in the database. Duplicate emails are not allowed.
    */
    $check_email = "SELECT * FROM students WHERE email = '$email'";
    $result = mysqli_query($conn, $check_email);

    /* 
        If the query returns any rows, the email is already registered.
        Display an error message instead of inserting duplicate data.
    */
    if (mysqli_num_rows($result) > 0) {
        $message = 'Error: Email already exists in the system!';
        $message_type = 'error';

    } else {

        /* 
            SQL INSERT query to add the new student record into the database.
            All sanitized form inputs are inserted into the students table.
        */
        $insert_query = "INSERT INTO students (first_name, last_name, email, date_of_birth, phone, address, enrollment_date, gpa, status, grade_level, gender) 
                         VALUES ('$first_name', '$last_name', '$email', '$date_of_birth', '$phone', '$address', '$enrollment_date', '$gpa', '$status', '$grade_level', '$gender')";
        
        /* 
            Execute the INSERT query.
            If successful, show a success message and clear the form inputs.
            If unsuccessful, show a database error message.
        */
        if (mysqli_query($conn, $insert_query)) {
            $message = 'Student added successfully!';
            $message_type = 'success';
            
            /* 
                Clear form data after successful submission so that 
                the previously entered values do not stay in the fields.
            */
            $_POST = array();

        } else {
            /* 
                If something goes wrong during the database insertion,
                display the error returned by MySQL.
            */
            $message = 'Error: ' . mysqli_error($conn);
            $message_type = 'error';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <!-- 
        Set viewport for responsive mobile-friendly layout 
    -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Title of the page displayed in the browser tab -->
    <title>Add New Student - Student Management System</title>

    <!-- Link to external CSS stylesheet for page styling -->
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">

        <!-- 
            Header section containing the system title, developer credit,
            and the displayed username with logout option.
        -->
        <div class="header">
            <h1>📚 Student Management System</h1>
            <p>Developed by Mithil - Future Billionaire Team</p>

            <!-- Display logged-in user's name and logout button -->
            <div style="margin-top: 15px; display: flex; justify-content: center; align-items: center; gap: 15px;">
                <span style="background: rgba(255,255,255,0.2); padding: 8px 20px; border-radius: 20px; font-size: 0.95em;">
                    👤 Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
                </span>

                <!-- Logout button redirects user to logout.php -->
                <a href="logout.php" style="background: rgba(255,255,255,0.9); color: #667eea; padding: 8px 20px; border-radius: 20px; text-decoration: none; font-weight: 600; font-size: 0.9em; transition: all 0.3s;" onmouseover="this.style.background='white'" onmouseout="this.style.background='rgba(255,255,255,0.9)'">
                    🚪 Logout
                </a>
            </div>
        </div>

        <!-- 
            Navigation menu for switching between dashboard,  
            add student page, and view students page.
        -->
        <div class="navigation">
            <ul class="nav-links">
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="add_student.php" class="active">Add Student</a></li>
                <li><a href="view_students.php">View All Students</a></li>
            </ul>
        </div>

        <!-- 
            Main content area containing the Add Student form 
        -->
        <div class="content">
            <h2 style="margin-bottom: 20px; color: #495057;">➕ Add New Student</h2>

            <!-- Display success or error message if present -->
            <?php if($message): ?>
                <div class="alert alert-<?php echo $message_type; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>

            <!-- 
                Form container for entering student personal and academic information 
            -->
            <div class="form-container">
                <form method="POST" action="">
                    
                    <!-- Personal Information Section -->
                    <h3 style="margin-bottom: 20px; color: #667eea;">Personal Information</h3>
                    
                    <!-- Row containing first name and last name fields -->
                    <div class="form-row">
                        <div class="form-group">
                            <label for="first_name">First Name *</label>
                            <input type="text" id="first_name" name="first_name" required>
                        </div>
                        <div class="form-group">
                            <label for="last_name">Last Name *</label>
                            <input type="text" id="last_name" name="last_name" required>
                        </div>
                    </div>

                    <!-- Row containing email and phone number -->
                    <div class="form-row">
                        <div class="form-group">
                            <label for="email">Email Address *</label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" placeholder="123-456-7890">
                        </div>
                    </div>

                    <!-- Row containing date of birth and gender -->
                    <div class="form-row">
                        <div class="form-group">
                            <label for="date_of_birth">Date of Birth *</label>
                            <input type="date" id="date_of_birth" name="date_of_birth" required>
                        </div>
                        <div class="form-group">
                            <label for="gender">Gender *</label>
                            <select id="gender" name="gender" required>
                                <option value="">Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                    </div>

                    <!-- Address field -->
                    <div class="form-group">
                        <label for="address">Address</label>
                        <textarea id="address" name="address" rows="3" placeholder="Enter full address..."></textarea>
                    </div>

                    <!-- Academic Information Section -->
                    <h3 style="margin: 30px 0 20px; color: #667eea;">Academic Information</h3>

                    <!-- Row with grade level and enrollment date -->
                    <div class="form-row">
                        <div class="form-group">
                            <label for="grade_level">Grade Level *</label>
                            <select id="grade_level" name="grade_level" required>
                                <option value="">Select Grade</option>
                                <option value="Grade 9">Grade 9</option>
                                <option value="Grade 10">Grade 10</option>
                                <option value="Grade 11">Grade 11</option>
                                <option value="Grade 12">Grade 12</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="enrollment_date">Enrollment Date *</label>
                            <input type="date" id="enrollment_date" name="enrollment_date" required>
                        </div>
                    </div>

                    <!-- Row with GPA and status -->
                    <div class="form-row">
                        <div class="form-group">
                            <label for="gpa">GPA (0.00 - 4.00) *</label>
                            <input type="number" id="gpa" name="gpa" step="0.01" min="0" max="4" value="0.00" required>
                        </div>
                        <div class="form-group">
                            <label for="status">Status *</label>
                            <select id="status" name="status" required>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="graduated">Graduated</option>
                                <option value="suspended">Suspended</option>
                            </select>
                        </div>
                    </div>

                    <!-- Buttons: Submit, Reset, Cancel -->
                    <div style="margin-top: 30px; display: flex; gap: 15px; justify-content: center;">
                        <button type="submit" class="btn btn-success">Add Student</button>
                        <button type="reset" class="btn btn-warning">Reset Form</button>
                        <a href="index.php" class="btn btn-danger">Cancel</a>
                    </div>

                </form>
            </div>
        </div>
    </div>
</body>
</html>

<?php 
/* 
    Close the database connection after all operations are completed.
    This frees system resources and ensures good database management.
*/
mysqli_close($conn); 
?>
