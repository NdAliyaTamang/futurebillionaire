<?php
/* 
    Include check_session.php to ensure the user is logged in.
    This prevents unauthorized access to student deletion functionality.
*/
include 'check_session.php';

/* 
    Include database configuration file to enable database connection.
*/
include 'config.php';

/* 
    Get the student ID from the URL query parameter 'id'.
    intval() ensures it is treated as an integer.
    Default to 0 if not provided.
*/
$student_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

/* 
    If no valid student ID is provided, redirect back to the dashboard.
    Prevents accidental or unauthorized access to deletion process.
*/
if ($student_id == 0) {
    header('Location: index.php');
    exit();
}

/* 
    SQL query to check whether the student exists in the database.
    This prevents attempting to delete a non-existent record.
*/
$check_query = "SELECT * FROM students WHERE student_id = $student_id";
$result = mysqli_query($conn, $check_query);

/* 
    If no student is found with the given ID, redirect back with an error.
*/
if (mysqli_num_rows($result) == 0) {
    header('Location: index.php?error=student_not_found');
    exit();
}

/* 
    SQL query to delete the student record from the database.
*/
$delete_query = "DELETE FROM students WHERE student_id = $student_id";

/* 
    Execute the delete query.
    If successful, redirect back with a success message.
    If unsuccessful, redirect back with an error message.
*/
if (mysqli_query($conn, $delete_query)) {
    header('Location: index.php?success=student_deleted');
} else {
    header('Location: index.php?error=delete_failed');
}

/* 
    Close the database connection after completing all operations.
    This frees system resources.
*/
mysqli_close($conn);

/* 
    Ensure the script stops executing after redirection.
*/
exit();
?>
