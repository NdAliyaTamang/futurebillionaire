<?php
/* Include session check to ensure the user is logged in */
include 'check_session.php';

/* Include database configuration to connect to MySQL */
include 'config.php';

/* Get total number of students from the database */
$total_students_query = "SELECT COUNT(*) as total FROM students";
$total_result = mysqli_query($conn, $total_students_query);
$total_students = mysqli_fetch_assoc($total_result)['total'];

/* Get total number of active students */
$active_students_query = "SELECT COUNT(*) as active FROM students WHERE status = 'active'";
$active_result = mysqli_query($conn, $active_students_query);
$active_students = mysqli_fetch_assoc($active_result)['active'];

/* Get average GPA of active students */
$avg_gpa_query = "SELECT AVG(gpa) as avg_gpa FROM students WHERE status = 'active'";
$avg_result = mysqli_query($conn, $avg_gpa_query);
$avg_gpa = mysqli_fetch_assoc($avg_result)['avg_gpa'];

/* Get search and filter input from URL parameters */
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$status_filter = isset($_GET['status']) ? mysqli_real_escape_string($conn, $_GET['status']) : '';
$grade_filter = isset($_GET['grade']) ? mysqli_real_escape_string($conn, $_GET['grade']) : '';

/* Build WHERE conditions based on search and filters */
$where_conditions = [];
if (!empty($search)) {
    $where_conditions[] = "(first_name LIKE '%$search%' OR last_name LIKE '%$search%' OR email LIKE '%$search%')";
}
if (!empty($status_filter)) {
    $where_conditions[] = "status = '$status_filter'";
}
if (!empty($grade_filter)) {
    $where_conditions[] = "grade_level = '$grade_filter'";
}

/* Combine WHERE conditions into a single SQL clause */
$where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";

/* Get list of students with applied filters, ordered by newest first */
$students_query = "SELECT * FROM students $where_clause ORDER BY student_id DESC";
$students_result = mysqli_query($conn, $students_query);

/* Get unique grade levels for the grade filter dropdown */
$grades_query = "SELECT DISTINCT grade_level FROM students ORDER BY grade_level";
$grades_result = mysqli_query($conn, $grades_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management System - Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📚 Student Management System</h1>
            <p>Developed by Mithil - Future Billionaire Team</p>
            <div style="margin-top: 15px; display: flex; justify-content: center; align-items: center; gap: 15px;">
                <span style="background: rgba(255,255,255,0.2); padding: 8px 20px; border-radius: 20px; font-size: 0.95em;">
                    👤 Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
                </span>
                <a href="logout.php" style="background: rgba(255,255,255,0.9); color: #667eea; padding: 8px 20px; border-radius: 20px; text-decoration: none; font-weight: 600; font-size: 0.9em; transition: all 0.3s;" onmouseover="this.style.background='white'" onmouseout="this.style.background='rgba(255,255,255,0.9)'">
                    🚪 Logout
                </a>
            </div>
        </div>

        <div class="navigation">
            <ul class="nav-links">
                <li><a href="index.php" class="active">Dashboard</a></li>
                <li><a href="add_student.php">Add Student</a></li>
                <li><a href="view_students.php">View All Students</a></li>
            </ul>
        </div>

        <div class="content">
            <h2 style="margin-bottom: 20px; color: #495057;">📊 Dashboard Overview</h2>

            <div class="stats-container">
                <div class="stat-card">
                    <h3>Total Students</h3>
                    <div class="number"><?php echo $total_students; ?></div>
                </div>
                <div class="stat-card">
                    <h3>Active Students</h3>
                    <div class="number"><?php echo $active_students; ?></div>
                </div>
                <div class="stat-card">
                    <h3>Average GPA</h3>
                    <div class="number"><?php echo number_format($avg_gpa, 2); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Inactive Students</h3>
                    <div class="number"><?php echo $total_students - $active_students; ?></div>
                </div>
            </div>

            <div class="search-filter-section">
                <h3>🔍 Search & Filter Students</h3>
                <form method="GET" action="" class="search-bar">
                    <div class="form-group">
                        <label for="search">Search by Name/Email</label>
                        <input type="text" id="search" name="search" placeholder="Enter name or email..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <div class="form-group">
                        <label for="status">Filter by Status</label>
                        <select id="status" name="status">
                            <option value="">All Statuses</option>
                            <option value="active" <?php echo $status_filter == 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo $status_filter == 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                            <option value="graduated" <?php echo $status_filter == 'graduated' ? 'selected' : ''; ?>>Graduated</option>
                            <option value="suspended" <?php echo $status_filter == 'suspended' ? 'selected' : ''; ?>>Suspended</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="grade">Filter by Grade</label>
                        <select id="grade" name="grade">
                            <option value="">All Grades</option>
                            <?php while($grade = mysqli_fetch_assoc($grades_result)): ?>
                                <option value="<?php echo $grade['grade_level']; ?>" <?php echo $grade_filter == $grade['grade_level'] ? 'selected' : ''; ?>>
                                    <?php echo $grade['grade_level']; ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>&nbsp;</label>
                        <button type="submit" class="btn btn-primary">Search</button>
                    </div>
                    <?php if($search || $status_filter || $grade_filter): ?>
                    <div class="form-group">
                        <label>&nbsp;</label>
                        <a href="index.php" class="btn btn-warning">Clear Filters</a>
                    </div>
                    <?php endif; ?>
                </form>
            </div>

            <h3 style="margin-bottom: 15px; color: #495057;">Recent Students</h3>
            
            <?php if(mysqli_num_rows($students_result) > 0): ?>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Grade</th>
                            <th>GPA</th>
                            <th>Status</th>
                            <th>Enrollment Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($student = mysqli_fetch_assoc($students_result)): ?>
                        <tr>
                            <td><?php echo $student['student_id']; ?></td>
                            <td><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($student['email']); ?></td>
                            <td><?php echo htmlspecialchars($student['grade_level']); ?></td>
                            <td><strong><?php echo number_format($student['gpa'], 2); ?></strong></td>
                            <td>
                                <span class="status-badge status-<?php echo $student['status']; ?>">
                                    <?php echo ucfirst($student['status']); ?>
                                </span>
                            </td>
                            <td><?php echo date('M d, Y', strtotime($student['enrollment_date'])); ?></td>
                            <td>
                                <div class="action-buttons">
                                    <a href="view_student.php?id=<?php echo $student['student_id']; ?>" class="btn btn-primary btn-sm">View</a>
                                    <a href="edit_student.php?id=<?php echo $student['student_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="delete_student.php?id=<?php echo $student['student_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this student?')">Delete</a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="no-records">
                <p>No students found matching your criteria.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

<?php 
/* Close database connection after all operations */
mysqli_close($conn); 
?>
